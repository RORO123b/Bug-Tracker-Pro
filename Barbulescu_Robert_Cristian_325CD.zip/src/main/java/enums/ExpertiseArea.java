package enums;

public enum ExpertiseArea {
    FRONTEND,
    BACKEND,
    DEVOPS,
    DESIGN,
    DB,
    FULLSTACK,
    MOBILE
}

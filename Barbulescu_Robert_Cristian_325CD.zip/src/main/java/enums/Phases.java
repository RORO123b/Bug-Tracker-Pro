package enums;

public enum Phases {
    TESTING,
    DEVELOPMENT,
    VERIFY
}

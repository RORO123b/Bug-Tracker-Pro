package commands;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import enums.TicketStatus;
import fileio.CommandInput;
import main.AppCenter;
import tickets.Ticket;
import tickets.action.ActionBuilder;
import users.Developer;

public final class ChangeStatusCommand implements Command {
    public ChangeStatusCommand() { }

    @Override
    public ObjectNode execute(final ObjectMapper mapper, final CommandInput command) {
        try {
            AppCenter appCenter = AppCenter.getInstance();
            Ticket ticket = appCenter.getTicketById(command.getTicketID());
            Developer dev = (Developer) appCenter.getUserByUsername(command.getUsername());

            if (!dev.getAssignedTickets().contains(ticket)) {
                throw new IllegalArgumentException("Ticket " + ticket.getId()
                        + " is not assigned to developer " + dev.getUsername() + ".");
            }
            if (ticket.getStatus() == TicketStatus.CLOSED) {
                return null;
            }

            ticket.getHistory().add(new ActionBuilder()
                    .action("STATUS_CHANGED")
                    .oldStatus(ticket.getStatus().toString())
                    .by(command.getUsername())
                    .timestamp(command.getTimestamp())
                    .build());
            ticket.changeStatus(command.getTimestamp());
            ticket.getHistory().getLast().setNewStatus(ticket.getStatus().toString());
        } catch (IllegalArgumentException e) {
            ObjectNode error = CommandHelper.createErrorNode(mapper, command,
                    e.getMessage());
            return error;
        }
        return null;
    }
}
